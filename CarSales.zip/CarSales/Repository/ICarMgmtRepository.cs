﻿using CarSales.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarSales.Repository
{
    public interface ICarMgmtRepository
    {
        Task<IEnumerable<CarMgmtModel>> GetAllAsync();
        Task<CarMgmtModel?> GetByIdAsync(int ID);

        Task InsertAsync(CarMgmtModel CarMgmt);

        Task SaveAsync();

        Task InsertAsyncfiles(MultipleFilesModel images);

        Task SaveAsyncfiles();
    }
}
