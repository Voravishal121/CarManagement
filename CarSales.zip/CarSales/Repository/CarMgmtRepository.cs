﻿using CarSales.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarSales.Repository
{
    public class CarMgmtRepository : ICarMgmtRepository
    {
        public Task<IEnumerable<CarMgmtModel>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public Task<CarMgmtModel> GetByIdAsync(int ID)
        {
            throw new NotImplementedException();
        }

        public Task InsertAsync(CarMgmtModel employee)
        {
            throw new NotImplementedException();
        }

        public Task InsertAsyncfiles(MultipleFilesModel images)
        {
            throw new NotImplementedException();
        }

        public Task SaveAsync()
        {
            throw new NotImplementedException();
        }

        public Task SaveAsyncfiles()
        {
            throw new NotImplementedException();
        }
    }
}
