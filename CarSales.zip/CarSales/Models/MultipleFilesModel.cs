﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CarSales.Models
{
    public class MultipleFilesModel 
    {
        [Key]
        public int ID { get; set; }
        public int CarMgtID { get; set; }
        public string Files { get; set; }
    }
}
