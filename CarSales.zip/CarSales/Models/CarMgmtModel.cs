﻿using CarSales.Custom_Validator;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CarSales.Models
{
    public class CarMgmtModel 
    {
        [Key]
        public int ID { get; set; }
        public string Brand { get; set; }
        public string Class { get; set; }

        [CheckRequiredFieldsValidation]
        [Required(ErrorMessage = "User name is required.")]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed.")]
        [Display(Name = "Model Name")]
        public string ModelName { get; set; }

        [Display(Name = "Model Code")]
        public string ModelCode { get; set; }
        public string Description { get; set; }
        public string Features { get; set; }
        [Required(ErrorMessage = "Price is required.")]

        [DataType(DataType.Currency)]
        public double Price { get; set; }

        [Required(ErrorMessage = "Date is required.")]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [DataType(DataType.DateTime)]
        [Display(Name = "Date of Manufacturing")]
        public DateTime DateofManufacturing { get; set; }

        [Required(ErrorMessage = "Please select files")]
        public string Files { get; set; }

    }
}
