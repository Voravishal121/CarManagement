﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;

namespace CarSales.Models
{
    public class CarMgmtViewModel
    {
        public int ID { get; set; }
        public string Brand { get; set; }
        public string Class { get; set; }
        public string ModelName { get; set; }

        public string ModelCode { get; set; }
        public string Description { get; set; }
        public string Features { get; set; }
      
        public double Price { get; set; }

      
        public DateTime DateofManufacturing { get; set; }


        public List<IFormFile> Files { get; set; }


    }
}
