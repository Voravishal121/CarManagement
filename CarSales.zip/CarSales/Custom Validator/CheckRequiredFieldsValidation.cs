﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarSales.Custom_Validator
{
    public class CheckRequiredFieldsValidation : ValidationAttribute
    {
        public CheckRequiredFieldsValidation()
       : base("{0} Filed is Mandatory.")
        {

        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
               // byte[] ASCIIValues = Encoding.ASCII.GetBytes(value.ToString());
                if (value.ToString() == "")
                {
                    var errorMessage = FormatErrorMessage(validationContext.DisplayName);
                    return new ValidationResult(errorMessage);

                }
            }
            return ValidationResult.Success;
        }
    }
}
