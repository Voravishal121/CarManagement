﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CarSales.Data;
using CarSales.Models;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace CarSales.Controllers
{
    public class CarMgmtController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHostingEnvironment hostingEnvironment;
        public CarMgmtController(ApplicationDbContext context, IHostingEnvironment hostingEnvironment)
        {
            _context = context;
            this.hostingEnvironment = hostingEnvironment;
        }

        // GET: CarMgmt
        public async Task<IActionResult> Index()
        {
            return View(await _context.CarMgmt.ToListAsync());
        }

        // GET: CarMgmt/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carMgmtModel = await _context.CarMgmt
                .FirstOrDefaultAsync(m => m.ID == id);
            if (carMgmtModel == null)
            {
                return NotFound();
            }

            return View(carMgmtModel);
        }

        // GET: CarMgmt/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CarMgmt/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Brand,Class,ModelName,ModelCode,Description,Features,Price,DateofManufacturing,Files")] CarMgmtViewModel carMgmtModel)
        {
            if (ModelState.IsValid)
            {
                CarMgmtModel carMgmtModel1 = new CarMgmtModel();

                carMgmtModel1.ID = carMgmtModel.ID;
                carMgmtModel1.Brand = carMgmtModel.Brand;
                carMgmtModel1.Class = carMgmtModel.Class;
                carMgmtModel1.ModelName = carMgmtModel.ModelName;
                carMgmtModel1.ModelCode = carMgmtModel.ModelCode;
                carMgmtModel1.Description = carMgmtModel.Description;
                carMgmtModel1.Features = carMgmtModel.Features;
                carMgmtModel1.Price = carMgmtModel.Price;
                carMgmtModel1.DateofManufacturing = carMgmtModel.DateofManufacturing;
                carMgmtModel1.Files = "";



                _context.Add(carMgmtModel1);
                await _context.SaveChangesAsync();

                int maxID = _context.CarMgmt.Max(p => p.ID);
                string uniqueFileName = null;
                if (carMgmtModel.Files != null && carMgmtModel.Files.Count > 0)
                {
                    // Loop thru each selected file
                    foreach (IFormFile photo in carMgmtModel.Files)
                    {
                        // The file must be uploaded to the images folder in wwwroot
                        // To get the path of the wwwroot folder we are using the injected
                        // IHostingEnvironment service provided by ASP.NET Core
                        string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "images");
                        // To make sure the file name is unique we are appending a new
                        // GUID value and and an underscore to the file name
                        uniqueFileName = Guid.NewGuid().ToString() + "_" + photo.FileName;
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                        // Use CopyTo() method provided by IFormFile interface to
                        // copy the file to wwwroot/images folder
                        photo.CopyTo(new FileStream(filePath, FileMode.Create));

                        MultipleFilesModel mf = new MultipleFilesModel();
                        mf.CarMgtID = maxID;
                        mf.Files = uniqueFileName;

                        _context.MultipleFiles.Add(mf);
                        await _context.SaveChangesAsync();
                    }
                }


                return RedirectToAction(nameof(Index));
            }
            return View(carMgmtModel);
        }

        // GET: CarMgmt/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carMgmtModel = await _context.CarMgmt.FindAsync(id);
            if (carMgmtModel == null)
            {
                return NotFound();
            }
            return View(carMgmtModel);
        }

        // POST: CarMgmt/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Brand,Class,ModelName,ModelCode,Description,Features,Price,DateofManufacturing,Files")] CarMgmtModel carMgmtModel)
        {
            if (id != carMgmtModel.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carMgmtModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarMgmtModelExists(carMgmtModel.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(carMgmtModel);
        }

        // GET: CarMgmt/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carMgmtModel = await _context.CarMgmt
                .FirstOrDefaultAsync(m => m.ID == id);
            if (carMgmtModel == null)
            {
                return NotFound();
            }

            return View(carMgmtModel);
        }

        // POST: CarMgmt/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var carMgmtModel = await _context.CarMgmt.FindAsync(id);
            _context.CarMgmt.Remove(carMgmtModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarMgmtModelExists(int id)
        {
            return _context.CarMgmt.Any(e => e.ID == id);
        }
    }
}
